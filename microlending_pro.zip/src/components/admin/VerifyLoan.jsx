

// import React, { useCallback, useEffect, useMemo, useState } from 'react';
// import { backEndCall, backEndCallObj } from '../../services/mainServiceFile';
// import { useNavigate } from 'react-router-dom';
// import { toast } from "react-hot-toast";
// import moment from 'moment';
// import { MovieContextProvider, useMovieContext } from '../comman/Context';
// import { verifyOTP } from '../../services/authService';

// function VerifyLoan() {
//     const navigate = useNavigate();
//     const { verifyloan, setVerifyloan } = useMovieContext();

//     const [btnDisabled, setBtnDisabled] = useState(false);
//     const [loading, setLoading] = useState(false); // State variable to track loading status

//     // useEffect(() => {
//     //     if (verifyloan.length <= 0) {
//     //         fetchData();
//     //     }
//     // }, []);

//     const fetchData = useCallback(async () => {
//         setLoading(true);
//         try {
//             const response = await backEndCall("/admin/loans_list");
//             console.log(response, "loanapproval");
//             setVerifyloan(response);
//         } catch (ex) {
//             if (ex.response && ex.response.status === 400) {
//                 toast.error(ex.response.data);
//             }
//         } finally {
//             setLoading(false);
//         }
//     }, [setVerifyloan]);

//     // Call fetchData when the length of verifyloan changes
//     useEffect(() => {
//         if (verifyloan.length === 0) {
//             fetchData();
//         }
//     }, [fetchData, verifyloan]);

//     // const fetchData = async () => {
//     //     setLoading(true); // Set loading to true when fetching data
//     //     try {
//     //         const response = await backEndCall("/admin/loans_list");
//     //         console.log(response, "loanapproval")
//     //         setVerifyloan(response);
//     //     } catch (ex) {
//     //         if (ex.response && ex.response.status === 400) {
//     //             toast.error(ex.response.data);
//     //         }
//     //     } finally {
//     //         setLoading(false); // Set loading to false after fetching data
//     //     }
//     // };

//     const callLoanStatusAPI = async (transactionId) => {
//         setBtnDisabled(true);
//         setLoading(true); // Set loading to true when making API call
//         console.log(transactionId, "transaction id");
//         try {
//             const response = await backEndCallObj("/admin/loan_status", { transaction_id: transactionId });
//             console.log(response, "loans status"); // Log the response from the API
//             toast.success(response, "loans completed");
//             fetchData();
//         } catch (ex) {
//             if (ex.response && ex.response.status === 400) {
//                 toast.error(ex.response.data);
//             }
//         } finally {
//             setLoading(false); // Set loading to false after API call
//             setBtnDisabled(false);
//         }
//     };

//     const handleRejectLoan = async (form_id, status) => {
//      
//         setBtnDisabled(true);
//         setLoading(true); // Set loading to true when making API call
//         try {
//             const response = await backEndCallObj("/admin/loan_approvel", { form_id, loan_status: status });
//             toast.success("Loan rejected successfully.");
//             console.log(response, "rejected loans");
//             fetchData();
//         } catch (ex) {
//             if (ex.response && ex.response.status === 400) {
//                 toast.error(ex.response.data);
//                 fetchData();
//             }
//         } finally {
//             
//             setLoading(false); // Set loading to false after API call
//             setBtnDisabled(false);
//         }
//     };

//     const handleApproveLoan = async (form_id, status) => {
//        
//         setBtnDisabled(true);
//         setLoading(true); // Set loading to true when making API call
//         try {
//             const response = await backEndCallObj("/admin/loan_approvel", { form_id, loan_status: status });
//             toast.success("Loan approved and submitted successfully.");
//             // Update state with the new data
//             setTimeout(() => {
//                 callLoanStatusAPI(response.transaction_id);
//             }, 9000);
//         } catch (ex) {
//             if (ex.response && ex.response.status === 400) {
//                 toast.error(ex.response.data);
//             }
//         } finally {
//           
//             setLoading(false); // Set loading to false after API call
//             setBtnDisabled(false);
//         }
//     };
//   
//     const formatDateTime = (Date) => {
//         let x = moment(Number(Date)).toDate();
//         return moment(x).format("DD-MMM-YYYY hh:mm A");
//     };

//     return (
//         <div className="user-details-container ">
//             <h5 className="mb-4">Loan applications</h5>
//             <div className='card'>
//                 <div className='card-body scrolleHidden ' style={{ overflowY: "auto", height: "70vh" }}>
//                     {loading && (
//                         <div className="text-center mt-3">
//                             <div className="spinner-border spiner-border-sm" style={{ color: "blue" }} role="status">
//                                 <span className="sr-only"></span>
//                             </div>
//                         </div>)}{/* Display loading indicator */}
//                     {!loading && verifyloan && (
//                         <div className="table-responsive">
//                             <table className="table border table-bordered   table-centered">
//                                 <thead>
//                                     <tr className="table-head text-center align-middle">
//                                         <th>Date</th>
//                                         <th>Loan ID</th>
//                                         <th>Name</th>
//                                         <th>Phone Number</th>
//                                         <th>Gender</th>
//                                         <th>Date of Birth</th>
//                                         <th>Loan Amount</th>
//                                         <th>Months</th>
//                                         <th>Loan Status</th>
//                                         <th>Action</th>
//                                     </tr>
//                                 </thead>
//                                 <tbody className="table-body align-middle text-center">
//                                     {verifyloan.map((loan) => (
//                                         <tr key={loan.id}>
//                                             <td>{formatDateTime(loan.date_of_applycation)}</td>
//                                             <td>{loan.form_id}</td>
//                                             <td>{loan.first_name} {loan.last_name}</td>
//                                             <td>{loan.phone_number}</td>
//                                             <td>{loan.gender}</td>
//                                             <td>{loan.dob}</td>
//                                             <td>{loan.loan_amount}</td>
//                                             <td>{loan.months}</td>
//                                             <td>{loan.loan_status}</td>
//                                             <td>
//                 <button className='btn btn-success btn-block me-3 mb-2' onClick={() => handleApproveLoan(loan.form_id, "Approved")} disabled={btnDisabled}>Approve</button>
//              <button className="btn btn-danger btn-block" onClick={() => handleRejectLoan(loan.form_id, "Rejected")} disabled={btnDisabled}>Reject</button> 
//                                                                                            </td>

//                                         </tr>
//                                     ))}
//                                 </tbody>
//                             </table>
//                         </div>
//                     )}
//                 </div>
//             </div>
//            
//         </div>
//     );
// }

// export default VerifyLoan;
import React, { useCallback, useEffect, useState } from 'react';
import { backEndCall, backEndCallObj } from '../../services/mainServiceFile';
import { useMovieContext } from '../comman/Context';
import { toast } from 'react-hot-toast';
import moment from 'moment';
import { Button, Modal } from 'react-bootstrap';
import { log } from 'joi-browser';

function VerifyLoan() {
    const { verifyloan, setVerifyloan, setUserprofileData, setAdminData } = useMovieContext();
    const [showModel, setShowModel] = useState(false);
    const [btnDisabled, setBtnDisabled] = useState(false);
    const [loading, setLoading] = useState(false);
    const [selectedLoanId, setSelectedLoanId] = useState(null);
    const [actionType, setActionType] = useState("");
    const fetchData = useCallback(async () => {
        setLoading(true);
        try {
            const response = await backEndCall("/admin/loans_list");
            setVerifyloan(response);
        } catch (ex) {
            console.error("Error fetching loan data:", ex);
        } finally {
            setLoading(false);
        }
    }, [setVerifyloan]);

    useEffect(() => {
        if (verifyloan.length === 0) {
            fetchData();
        }
    }, [fetchData, verifyloan.length]);

    const callLoanStatusAPI = async (transactionId) => {
        console.log("success sms")
        setBtnDisabled(true);
        setLoading(true);
        try {
            const response = await backEndCallObj("/admin/loan_status", { transaction_id: transactionId });
            toast.success(response, "Loan status updated");
            fetchData();
        } catch (ex) {
            console.error("Error updating loan status:", ex);
            if (ex.response && ex.response.status === 400) {
                toast.error(ex.response.data);
            }
        } finally {
            setLoading(false);
            setBtnDisabled(false);
        }
    };
    // Add this line to define the actionType state

    const handleRejectLoan = async (form_id) => {
        setSelectedLoanId(form_id);
        setActionType("reject"); // Set actionType to 'reject'
        setShowModel(true);
    };

    const handleApproveLoan = async (form_id) => {
        setSelectedLoanId(form_id);
        setActionType("approve"); // Set actionType to 'approve'
        setShowModel(true);
    };



    // const handleRejectLoan = async (form_id, loan_status) => {
    //     setSelectedLoanId(form_id, loan_status);
    //     setShowModel(true);
    // };

    // const handleApproveLoan = async (form_id, loan_status) => {
    //     setSelectedLoanId(form_id, loan_status);
    //     setShowModel(true);
    // };
    const handleConfirm = async () => {
        setShowModel(false);
        setBtnDisabled(true);
        setLoading(true);

        try {
            if (selectedLoanId && actionType) { // Ensure actionType is set
                let response;
                const loanStatus = actionType === "approve" ? "Approved" : "Rejected";
                response = await backEndCallObj("/admin/loan_approvel", { form_id: selectedLoanId, loan_status: loanStatus });
                setUserprofileData(null)
                setAdminData(null)
                setTimeout(() => {
                    callLoanStatusAPI(response.transaction_id);
                }, 9000);


            } else {
                console.error("Error: selectedLoanId or actionType is not set.");
                toast.error("Loan ID or action type is not set.");
            }
        } catch (ex) {
            console.error("Error confirming action:", ex);
            if (ex.response && ex.response.status === 400) {
                toast.error(ex.response.data);
            }
        } finally {
            setLoading(false);
            setBtnDisabled(false);
        }
    };

    // const handleConfirm = async () => {
    //     setShowModel(false);
    //     setBtnDisabled(true);
    //     setLoading(true);


    //     try {
    //         if (selectedLoanId) {
    //             console.log(selectedLoanId, "loaneid");
    //             let response;
    //             if (selectedLoanId) {
    //                 response = await backEndCallObj("/admin/loan_approvel", { form_id: selectedLoanId, loan_status: "Approved" });
    //                 toast.success("Loan approved and submitted successfully.");

    //             } else if (selectedLoanId) {
    //                 response = await backEndCallObj("/admin/loan_approvel", { form_id: selectedLoanId, loan_status: "Rejected" });
    //                 toast.success("Loan rejected successfully.");
    //             }
    //             // Log the response for debugging
    //             console.log("API Response:", response);
    //             // Check if response is valid
    //             if (response && response.transaction_id) {
    //                 setTimeout(() => {
    //                     callLoanStatusAPI(response.transaction_id);
    //                 }, 9000);
    //             } else {
    //                 // Log error if response is invalid
    //                 console.error("Error: Invalid response from the backend API.", response);
    //                 toast.error("Invalid response from the backend API.");
    //             }
    //         } else {
    //             // Log error if selectedLoanId is not set
    //             console.error("Error: selectedLoanId is not set.");
    //             toast.error("Selected loan ID is not set.");
    //         }
    //     }



    //     catch (ex) {
    //         console.error("Error confirming action:", ex);
    //         if (ex.response && ex.response.status === 400) {
    //             toast.error(ex.response.data);
    //         }
    //     } finally {
    //         setLoading(false);
    //         setBtnDisabled(false);
    //     }
    // };




    const formatDateTime = (date) => {
        return moment(date).format("DD-MMM-YYYY hh:mm A");
    };

    return (
        <div className="user-details-container">
            <h5 className="mb-4">Loan applications</h5>
            <div className='card'>
                <div className='card-body scrolleHidden' style={{ overflowY: "auto", height: "70vh" }}>
                    {loading && (
                        <div className="text-center mt-3">
                            <div className="spinner-border spiner-border-sm" style={{ color: "blue" }} role="status">
                                <span className="sr-only"></span>
                            </div>
                        </div>
                    )}
                    {!loading && verifyloan && (
                        <div className="table-responsive">
                            <table className="table border table-bordered table-centered">
                                <thead>
                                    <tr className="table-head text-center align-middle">
                                        <th>Date</th>
                                        <th>Loan ID</th>
                                        <th>Name</th>
                                        <th>Phone Number</th>
                                        <th>Gender</th>
                                        <th>Date of Birth</th>
                                        <th>Loan Amount</th>
                                        <th>Months</th>
                                        <th>Loan Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody className="table-body align-middle text-center">
                                    {verifyloan.map((loan) => (
                                        <tr key={loan.id}>
                                            <td>{formatDateTime(loan.date_of_application)}</td>
                                            <td>{loan.form_id}</td>
                                            <td>{loan.first_name} {loan.last_name}</td>
                                            <td>{loan.phone_number}</td>
                                            <td>{loan.gender}</td>
                                            <td>{loan.dob}</td>
                                            <td>{loan.loan_amount}</td>
                                            <td>{loan.months}</td>
                                            <td>{loan.loan_status}</td>
                                            <td>
                                                <Button variant="success" onClick={() => handleApproveLoan(loan.form_id, "Approved")} disabled={btnDisabled} className='mb-2 me-2'>Approve</Button>
                                                <Button variant="danger" onClick={() => handleRejectLoan(loan.form_id, "Rejected")} disabled={btnDisabled}>Reject</Button>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    )}
                </div>
            </div>
            {showModel ? (
                <Modal show={showModel} onHide={() => setShowModel(false)}>
                    <Modal.Header closeButton>
                        <Modal.Title>Confirm Action</Modal.Title>
                    </Modal.Header>
                    <Modal.Body>Are you sure you want to perform this action?</Modal.Body>
                    <Modal.Footer>
                        <Button variant="secondary" onClick={() => setShowModel(false)}>Cancel</Button>
                        <Button variant="primary" onClick={handleConfirm} disabled={btnDisabled}>Confirm</Button>
                    </Modal.Footer>
                </Modal>
            ) : null}
        </div>
    );
}

export default VerifyLoan;
