
// import React, { useEffect, useState } from 'react';
// import { toast } from "react-hot-toast";
// import { backEndCall } from '../../services/mainServiceFile';

// import { useMovieContext } from '../comman/Context';

// function TransactionHistory() {

//     const { transactionHistory, setTransactionHistory, error, setError } = useMovieContext();
//     const [loading, setLoading] = useState(false)
//     const fetchTransactionHistory = async () => {
//         setLoading(true)
//         try {
//             const response = await backEndCall('/users/transaction_history_all');
//             // console.log(response, "transection histery")
//             if (Array.isArray(response)) {
//                 setTransactionHistory(response);
//             } else {
//                 setTransactionHistory([]);
//             }
//             setLoading(false);
//         } catch (ex) {
//             if (ex.response && ex.response.status === 400) {
//                 toast.error(ex.response.data);
//             } else {
//                 toast.error(ex.response.data);
//             }
//             setError(ex.message);
//             setLoading(false);
//         }
//     };

//     useEffect(() => {

//         if (transactionHistory.length <= 0) {
//             fetchTransactionHistory();
//         }
//     }, []);

//     return (
//         <div className="user-details-container">
//             <h5 className="mb-4">Transaction History</h5>
//             <div className='card transections-hisroty  '>
//                 <div className='card-body'>


//                     <div className="table-responsive">

//                         <table className="table border table-bordered table-centered text-center">
//                             <thead>
//                                 <tr className="table-head">
//                                     <th scope="col">Transaction Id</th>
//                                     <th scope="col">Receiver Id</th>
//                                     <th scope="col">Sender Id</th>
//                                     <th scope="col">Transaction Type</th>
//                                     <th scope="col">Transaction Status</th>
//                                     <th scope="col">Amount</th>
//                                     {/* <th scope="col">Comment</th> */}
//                                     <th scope="col">Transaction Date</th>
//                                 </tr>
//                             </thead>
//                             <tbody className="table-body">
//                                 {loading ? (
//                                     <tr>
//                                         <td colSpan="7" className="text-center">
//                                             <div className="spinner-border spiner-border-sm" style={{ color: "blue" }} role="status">
//                                                 <span className="sr-only"></span>
//                                             </div>
//                                         </td>
//                                     </tr>
//                                 ) : transactionHistory?.length === 0 ? (
//                                     <tr>
//                                         <td colSpan="7" className="text-center">No transactions found.</td>
//                                     </tr>
//                                 ) : (
//                                     transactionHistory.map(history => (
//                                         <tr key={history.transaction_id}>
//                                             <td>{history.transaction_id}</td>
//                                             <td>{history.receiver_id}</td>
//                                             <td>{history.sender_id}</td>
//                                             <td>{history.transactionType}</td>
//                                             <td>{history.transaction_status}</td>
//                                             <td>{history.amount}</td>
//                                             <td>{new Date(history.transactionDate).toLocaleString()}</td>
//                                         </tr>
//                                     ))
//                                 )}
//                             </tbody>
//                         </table>

//                     </div>
//                 </div>
//             </div>
//         </div>
//     );
// }

// export default TransactionHistory;
import React, { useState, useEffect } from 'react';
import { toast } from "react-hot-toast";
import { backEndCall, backEndCallObj } from '../../services/mainServiceFile';
import authService from '../../services/authService';
import moment from 'moment';
import Joi from 'joi-browser';
import { Date_Input, SearchInput } from '../comman/All-Inputs';

function TransactionHistory() {
    const [transactionHistory, setTransactionHistory] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [filterDisabled, setFilterDisabled] = useState(false);

    const [formData, setFormData] = useState({
        start_date: "",
        end_date: "",
        id: ""

    });

    const schema = Joi.object({
        start_date: Joi.date().required(),
        end_date: Joi.date().min(Joi.ref('start_date')).required(),
        // transaction_id: Joi.string().min(12).max(22).required().allow(''),
        // sender_id: Joi.string().min(12).max(12).required().allow(''),
        // received_id: Joi.string().min(12).max(12).required().allow('')
        id: Joi.string().min(12).max(12).required().allow('')
    });

    const fetchTransactionHistory = async () => {
        try {
            const response = await backEndCall('/users/transaction_history');
            if (Array.isArray(response)) {
                setTransactionHistory(response);
            } else {
                setTransactionHistory([]);
            }
            setLoading(false);
        } catch (ex) {
            if (ex.response && ex.response.status === 400) {
                toast.error(ex.response.data);
            }
            setError(ex.message);
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchTransactionHistory();
    }, []);

    const handleSubmit = async (e) => {
        console.log("hhhhhhhhhhhhhhh")
        e.preventDefault();


        try {
            setFilterDisabled(true)
            console.log(formData)
            const response = await backEndCallObj("/users/transaction_filtered", formData);
            console.log(response, "responsedate")
            setFilterDisabled(false)
        } catch (ex) {
            if (ex.response && ex.response.status === 400) {
                toast.error(ex.response.data);
            }
        }
        finally {
            setFilterDisabled(false)
        }
    };


    return (
        <>
            <div className="user-details-container p-4">
                <h5 className="mb-4">Transactions</h5>
                <div className="table-responsive">
                    <div >
                        <form onSubmit={handleSubmit}>
                            <div className="row mb-3 d-flex">
                                <div className="col-12 col-xl-4 col-md-4 col-sm-12">

                                    <label htmlFor="startDate" className="form-label">Start Date<span className="text-danger">*</span></label>
                                    <Date_Input
                                        type={"date"}
                                        value={formData["start_date"]}
                                        name={"start_date"}
                                        SetForm={setFormData}
                                        schema={schema["start_date"]}

                                        autoFocus={true}
                                        required
                                    />
                                </div>


                                <div className="col-12 col-xl-4 col-md-4 col-sm-12">

                                    <label htmlFor="endtDate" className="form-label">end Date<span className="text-danger">*</span></label>
                                    <Date_Input
                                        type={"date"}
                                        value={formData["end_date"]}
                                        name={"end_date"}
                                        SetForm={setFormData}
                                        schema={schema["end_date"]}

                                        autoFocus={true}
                                        required
                                    />
                                </div>

                                <div className="col-12 col-xl-4 col-md-4 col-sm-12">
                                    <SearchInput
                                        type="text"
                                        name="id"
                                        value={formData["id"]}
                                        placeholder="received_id / transaction_id / sender id"
                                        SetForm={setFormData}
                                        schema={schema["id"]}
                                    />
                                </div>

                                <div className="text-center">
                                    <button type="submit" className="btn btn-primary" disabled={filterDisabled}>
                                        Search
                                    </button>
                                </div>
                            </div>


                        </form>
                    </div>
                    {loading && (
                        <div className="text-center mt-3">
                            <div className="spinner-border spiner-border-sm" style={{ color: "#efefef" }} role="status">
                                <span className="sr-only"></span>
                            </div>
                        </div>
                    )}
                    {!loading && transactionHistory.length === 0 && (
                        <div>No transactions found.</div>
                    )}
                    {!loading && transactionHistory.length > 0 && (
                        <table className="table border table-bordered table-centered">
                            <thead>
                                <tr className="table-head">
                                    <th scope="col">TransactionId</th>
                                    <th scope="col">ReceiverId</th>
                                    <th scope="col">SenderId</th>
                                    <th scope="col">TransactionType</th>
                                    <th scope="col">TransactionStatus</th>
                                    <th scope="col">Amount</th>
                                    <th scope="col">Comment</th>
                                    <th scope="col">TransactionDate</th>
                                </tr>
                            </thead>
                            <tbody className="table-body">
                                {transactionHistory.map(history => (
                                    <tr key={history.transaction_id}>
                                        <td>{history.transaction_id}</td>
                                        <td>{history.receiver_id}</td>
                                        <td>{history.sender_id}</td>
                                        <td>{history.transactionType}</td>
                                        <td>{history.transaction_status}</td>
                                        <td>{history.amount}</td>
                                        <td>{history.comment}</td>
                                        <td>{new Date(history.transactionDate).toLocaleString()}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    )}
                </div >
            </div >
        </>
    );
}

export default TransactionHistory;
