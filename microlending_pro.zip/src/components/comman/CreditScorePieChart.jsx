
import { useState } from 'react';
import ReactApexChart from 'react-apexcharts';

const CreditScorePieChart = () => {
    const [series, setSeries] = useState([44, 55, 13, 33]);

    const options = {
        chart: {
            width: 380,
            type: 'donut',
        },
        dataLabels: {
            enabled: false
        },
        responsive: [{
            breakpoint: 480,
            options: {
                chart: {
                    width: 200
                },
                legend: {
                    show: false
                }
            }
        }],
        legend: {
            position: 'right',
            offsetY: 0,
            height: 230,
        }
    };

    // const appendData = () => {
    //     const arr = [...series];
    //     arr.push(Math.floor(Math.random() * (100 - 1 + 1)) + 1);
    //     setSeries(arr);
    // };

    // const removeData = () => {
    //     if (series.length === 1) return;
    //     const arr = [...series];
    //     arr.pop();
    //     setSeries(arr);
    // };

    const randomize = () => {
        const arr = series.map(() => Math.floor(Math.random() * (100 - 1 + 1)) + 1);
        setSeries(arr);
    };

    const reset = () => {
        setSeries([44, 55, 13, 33]);
    };

    return (
        <div>
            <div className="chart-wrap">
                <div id="chart">
                    <ReactApexChart options={options} series={series} type="donut" width={380} />
                </div>
            </div>
            {/* <div className="actions">
                <button onClick={appendData}>+ ADD</button>
                <button onClick={removeData}>- REMOVE</button>
                <button onClick={randomize}>RANDOMIZE</button>
                <button onClick={reset}>RESET</button>
            </div> */}
        </div>
    );
};

export default CreditScorePieChart;
// ;
// import { useState } from 'react';
// import ReactApexChart from 'react-apexcharts';

// const CreditScorePieChart = ({ creditScores }) => {
//     console.log(creditScores)
//     // Convert the credit score to a percentage (e.g., 7.5 to 75)
//     const scorePercentage = creditScores * 10;

//     // Calculate the remaining percentage (100 - scorePercentage)
//     const remainingPercentage = 1000 - scorePercentage;

//     // Define the series data for the pie chart
//     const series = [scorePercentage, remainingPercentage];

//     const options = {
//         chart: {
//             width: 380,
//             type: 'donut',
//         },
//         dataLabels: {
//             enabled: false
//         },
//         responsive: [{
//             breakpoint: 480,
//             options: {
//                 chart: {
//                     width: 200
//                 },
//                 legend: {
//                     show: false
//                 }
//             }
//         }],
//         legend: {
//             position: 'right',
//             offsetY: 0,
//             height: 230,
//         }
//     };

//     return (
//         <div>
//             <div className="chart-wrap">
//                 <div id="chart">
//                     <ReactApexChart options={options} series={series} type="donut" width={380} />
//                 </div>
//             </div>
//         </div>
//     );
// };

// export default CreditScorePieChart;
// import { useState } from 'react';
// import ReactApexChart from 'react-apexcharts';

// const CreditScorePieChart = ({ creditScores }) => {
//     // Convert the credit score to a percentage (e.g., 7.5 to 75)
//     const scorePercentage = creditScores * 10;

//     // Calculate the remaining percentage (100 - scorePercentage)
//     const remainingPercentage = 1000 - scorePercentage;

//     // Define the series data for the pie chart
//     const series = [scorePercentage, remainingPercentage];
//     const colors = ['#4caf50', '#FF5722'];
//     // Define the options for the pie chart
//     const options = {
//         chart: {
//             width: 380,
//             type: 'donut',
//         },
//         // Labels for the chart sections
//         labels: [`creadit scrore${creditScores}`, 'Remaining'], // Credit score value and remaining percentage
//         dataLabels: {
//             enabled: false
//         },
//         colors: colors,
//         responsive: [{
//             breakpoint: 480,
//             options: {
//                 chart: {
//                     width: 200
//                 },
//                 legend: {
//                     show: false
//                 }
//             }
//         }],
//         legend: {
//             position: 'right',
//             offsetY: 0,
//             height: 230,
//         }
//     };

//     return (
//         <div>
//             <div className="chart-wrap">
//                 <div id="chart">
//                     {/* Render the pie chart */}

//                     <ReactApexChart options={options} series={series} type="donut" width={380} />
//                 </div>
//             </div>
//         </div>
//     );
// };

// export default CreditScorePieChart;
