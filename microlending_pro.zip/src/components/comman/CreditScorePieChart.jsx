
import React from "react";
// import “./styles.css”;
import ReactSpeedometer from "react-d3-speedometer";
const CibilScoreGauge = (cibile_score) => {
    const value = cibile_score.creditScores * 100;
    const creditScores = String(value / 100);
    // Define styles for different credit score ranges
    const segmentStyles = {
        bad: { color: "red" },
        fair: { color: "orange" },
        avarage: { color: "yellowgreen" },
        good: { color: "lightgreen" },
        excellent: { color: "darkgreen" }
    };



    return (
        <div className="App">
            {/* Display labels with associated styles */}
            <div className="d-flex justify-content-center fs-20">

                <span className="me-3" style={segmentStyles.bad}>bad</span>
                <span className="me-3" style={segmentStyles.fair}>fair</span>
                <span className="me-3" style={segmentStyles.avarage}>avarage</span>

                <span className="me-3" style={segmentStyles.good}>good</span>
                <span className="me-3" style={segmentStyles.excellent}>excellent</span>
            </div>
            <div className="d-flex justify-content-center">
                <ReactSpeedometer
                    width={300}
                    height={200}
                    paddingHorizontal={50}
                    value={value}
                    currentValueText={`credit score: ${creditScores}`}
                    customSegmentLabels={[
                        {
                            text: "1-2",
                            position: "INSIDE",
                            color: "#555"
                        },
                        {
                            text: "3-4",
                            position: "INSIDE",
                            color: "#555"
                        },
                        {
                            text: "5-6",
                            position: " INSIDE",
                            color: " #555"
                        },
                        {
                            text: "7-8",
                            position: "INSIDE",
                            color: "#555"
                        },
                        {
                            text: "9-10",
                            position: "INSIDE",
                            color: "#555"
                        },
                    ]}
                />
            </div>
        </div>
    );
}
export default CibilScoreGauge;